%5-26 work

[xr7,fval,exitflag,putput,lambda]=fmincon(@AAr7,y8,[],[],[],[],[],[],@consphere);
%using 81 points to caculate spherical 7 design
% AA8(xr7);
[Y1,DetG,W,Wp]=AA7(xr7);
[Y2,DetG,W,Wp]=AA7(y8);
AA8(xr7)
[xr8,fval,exitflag,putput,lambda]=fmincon(@AAr8,xr7,[],[],[],[],[],[],@consphere);
% Y=AA8();%is a spherical 8 design
[Y,DetG,W,Wp]=AA8(xr8)
[Y,DetG,W,Wp]=AA8(y8)
spherepoint(xr7)

spherepoint(xr8)

figure(2),
spherepoint(y8)
% d=xr8-y8;
%%%------------------------------------------------------------------------
%%%-----------------------------------
% for extremal point in this way ,we do not get the similarly result
%     since the system is depend on the initial points sensetivily
[xr7,fval,exitflag,putput,lambda]=fmincon(@AAr7,e8,[],[],[],[],[],[],@consphere);
%using 81 points to caculate spherical 7 design
% AA8(xr7);
[Y1,DetG,W,Wp]=AA7(x7);
[Y2,DetG,W,Wp]=AA7(y8);
AA8(xr7)
[xr8,fval,exitflag,putput,lambda]=fmincon(@AAr8,xr7,[],[],[],[],[],[],@consphere);
% Y=AA8();%is a spherical 8 design
[Y,DetG,W,Wp]=AA8(xr8)
[Y,DetG,W,Wp]=AA8(y8)
spherepoint(xr8)
figure(2),
spherepoint(y8)