% 
% %%%%%%%%%%%8
%  XX=[0.4082,0.7071,-0.5774;0.4082,-0.7071,-0.5774;0.8165,0,0.5774;-0.4082,0.7071,0.5774;-0.4082,-0.7071,0.5774;-0.8165,0,-0.5774;]
% % %%%%%%%%%20mian ti
%  XX=[
%       0.250254 -0.916162 -0.313083
%       0.320072 -0.078054 -0.944171
%       0.437594 -0.598061  0.671442
%       0.550563  0.758025 -0.349682
%       0.623196  0.436642  0.648821
%       0.975676 -0.177816 -0.128204
%       -0.250253  0.916161  0.313082
%       -0.320073  0.078054  0.944172
%       -0.437593  0.598061 -0.671442
%       -0.550563 -0.758024  0.349683
%       -0.623195 -0.436643 -0.648822
%       -0.975676  0.177817  0.128204
%    ];%12
extremal
[f,N,XX,minY,minY1,ht,at,rs] = Amin(e19,19)
XX=XX'
[Y, Q, R] = normalize(XX)
pltsphp(XX')
x=XX(:,1),y=XX(:,2),z=XX(:,3)
  [rho, theta, phi]=spherical_angle_ed(x, y, z);

[x10, y10, z10]=splat(rho, theta, phi);



make_plot=1
sphere=1
faceopaque=0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
TRI = delaunay(x10, y10);
    
% if sphere == 1
%     [TRI, x, y, z]=make_sphere(TRI, x, y, z);
% end

% if make_plot ==1
%     figure(10);
%     if faceopaque == 1
        h=trisurf(TRI,x,y,z, 'FaceColor', [1 1 1], 'EdgeColor', 0.5*[1 1 1], 'LineWidth', 1 );
%     else
        h=trisurf(TRI,x,y,z, 'FaceColor', 'none', 'EdgeColor', 0.7*[1 1 1],'LineWidth', 1 );
%     end
    axis equal;

    xlabel('x-axis (m)', 'Fontsize', 16');
    ylabel('y-axis (m)', 'Fontsize', 16');
    zlabel('z-axis (m)', 'Fontsize', 16');
    title( ['Microphone Structure Struts and Nodes'], 'Fontsize', 16');
      axis equal;
    grid off;

% end
clear all
%%%%%%%%%%%%%%%%%%%%%incribed of a sphere
hold on,sphere
alpha(0.2)
shading('interp')
axis off
title('')
n=10
M=moviein(n)
for j=1:n
view([-37.5+j*10,30]);
M(:,j)=getframe;  %��׽����
end
movie(M,5)  
%����
% MATLAB�Դ�����
xpmovie bibes;
xpmovie logospin
xpmovie crulspin
