
 
%  
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
%  L=10;
% % N=200
% F=[];NN=[];MY=[];MY1=[];
% H=[];Angle=[];
% XS=[];RS=[];
% t=19;
% for T=t-1:t+5;
% N=(T+1)^2;
% X0=Getextremal(tt,nn)
% [f,N,XX,minY,minY1,ht,at,s] = Amin(X0,L);
% 
% 
% 
% 
% 
% 
% %  for N=10:144
% %  N=441
% % z = 2*rand(1,N-1) - 1;
% %     s0 = acos(z);
% %     s0 = [s0 (2*pi)*rand(1,N-2)];
% %     %s0 = ss;
% %     X0 = s2cn(s0);
% %     s0 = c2sn(X0);
% %     fprintf('Pseudo-random intial points\n');
% % 
% % N=(L+2)^2
% % X0= ptsspb(N, 8, 9, 1.8);
% % [f,N,XX,minY,minY1,ht,at,s] = Amin(X0,L);
% %   KMatrix1(end+1,:) = KArray1 ;
% %             KMatrix2(end+1,:) = KArray2 ;
% F(end+1,:)=f;
% NN(end+1,:)=N;
% XS=[XS,XX];
% MY(end+1,:)=minY;
% MY1(end+1,:)=minY1;
% H(end+1,:)=ht;
% Angle(end+1,:)=at;RS(end+1,:)=rs;
%  end
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x=10:144
% %   x=200:201;
% figure(11),plot(x,F,'*'),grid on,xlabel('Number of Points');title('The behavior of final A_{N,10} ','fontSize',12)
%   figure(12),plot(x,MY,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal singular vaule of Y_{10}','fontSize',12)
%    figure(13),plot(x,MY1,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal singular vaule of Y_{10+1}','fontSize',12)
%     figure(14),plot(x,H,'*'),grid on,xlabel('Number of Points');title('The behavior of mesh norm ','fontSize',12)
%      figure(15),plot(x,Angle,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal angle ','fontSize',12)
%  
%  figure(16),plot(x,RS,'*'),grid on,xlabel('Number of Points');title('The behavior of 2-norm of residual  ','fontSize',12)
% %%%%%%%%%%%%%%%%%%%%%%%%5
% %%
function X=Getextremal(tt,nn)
% tt=T(j);
tstr=sprintf('%.3f',tt/1e3);
tstr=tstr(3:end);
% nn=N(j)
nstr=sprintf('%.5f',nn/1e5);
nstr=nstr(3:end);
% fstr=['load Points/MD/md' tstr '.' nstr];
fstr=['load md/md' tstr '.' nstr];
eval(fstr);
 eval(['x=md' tstr '(:,1:3);']);
 X=x';