function [G,detG,eignvalue2,meaneign,tr,condG,eigG]=Gram(XX,L1)
% [G,detG,eignvalue2,meaneign,tr,condG,eigp]=Gram(XX,L1)
%%%This is a function of the gram matrix in Chen and Womer' s 2006'w work.
%Andbach 
G=gramxddL(XX, L1);
G=G+ones(size(G));
a=4*pi;
G=G/a;
detG=det(G);

eigG=eig(G);
tr=sum(eigG);
max1=max(eigG);
min1=min(eigG);
% eigp=find(eigG>-7.054502561475866e-013);

meaneign=mean(eigG);
eignvalue2=[min1,meaneign,max1];
condG=cond(G);


