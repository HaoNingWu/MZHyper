

extremal
s = c2sn(e10);L=10
d=(L+1)^2
% s0=s0'
XX=s;
% f=((d^2)/(4*pi))*eps
f=2;
f1=5;
gramxddn(e10);
%%%%%%%%
if f>-((d^2)/(4*pi)) & f1> 1e-13;
    s0=XX;
[f,sss]=MaxGram(s0,L)
s=sss
% s=s2cf(sss)
[f,N,XX,detG] = Amin(s,L);
f,detG,
XX=c2sf(XX);
end

% s = c2sn(X);
% >> [f, Df] = logdetfg(s,L)
%%s2cn