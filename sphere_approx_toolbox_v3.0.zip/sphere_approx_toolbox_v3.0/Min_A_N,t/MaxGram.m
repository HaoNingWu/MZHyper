function [f,sss]=MaxGram(s0,L)
tolx = 1e-14;
tolf = 1e-12;
opt = optimset('Display', 'Iter', 'TolX', tolx, 'TolFun', tolf);

%%%%%%%%%%%%%maximize determinte
% [f, Df] = logdetfg(s)
L=10
  opt = optimset(opt, 'GradObj', 'on', 'LargeScale', 'off');
%     opt = optimset(opt, 'InitialHessType', 'scaled-identity');
    [sss, fs, flag] = fminunc('logdetfg', s0, opt, L);
%     fprintf('FMINUNC: flag = %d\n', flag);
   [f, Df] = logdetfg(sss,L)
   f;sss=s2cn(sss);