function [sd,minsd,YTT]=YSVD(L,XX)
[THETA,PHI,R] = cart2sph(XX(1,:),XX(2,:),XX(3,:));
a=0;
a=THETA;
THETA=PHI;
PHI=a;
%%%%%%%%%%%%%%%%%%%%%%5
% YL=[]
YT= spharmrds(0, cos(THETA),PHI);
YT=YT';
% YT=[]
for i=1:L
   
    YL= spharmrds(i, cos(THETA),PHI);
    
    YT=[YT,YL'];
    % YT(:,end+1)=YL
end
YTT=YT';
sd=svd(YTT);
minsd=min(sd);