function [lagnrm] = findmax1a(X, n, Ginv, ftol, NRM, ipr)
% [lagnrm] = findmax1a(X, n, Ginv, ftol, NRM, ipr)
% Claulate the NRM of the Lagrangians of degree n for the point set X
% over the sphere S^2. Ginv = inv(G)
% NRM may be 1, 2, or Inf or any combination of these
% Estimate local maxima of the norm of Lagrangians over S^2
% Then find global maximum accurately by nonlinear optimization from
% each of these local maxima

% NOTE: For 2-norm (NRM = 2) find maximum of Lagrangian sum of squares
% normlagfg returns sum of square of Lagrangians while
% normgf retunr 2-norm, so square root of values from normlagfg

t0 = tic;

if nargin < 5
    ipr = 0;
end;
if nargin < 4
    nrm = 1;
end;
if nargin < 3
    % Check for local maxima above ftol*discrete maximum
    ftol = 0.98;
end;
if nargin < 2
    G = gramxddn(X, n);
    Ginv = inv(G);
end;

lagnrm.inf = []; lagnrm.inf_fmx = []; lagnrm.inf_pts = [];
lagnrm.two = []; lagnrm.two_fmx = []; lagnrm.two_pts = [];
lagnrm.one = []; lagnrm.one_fmx = []; lagnrm.one_pts = [];

[h, ht, YY, YC] = meshn(X, ipr);

% Inital sample points for maximum over sphere
% Centroid of traingles in Delaunany triangualr and points
YS = [YC X];
[f1, f2, fi, F1, F2, Fi] = normlag(X, n, Ginv, YS, ipr);
% Convert to sum of squares for comparison with values from normlagfg
f2 = f2^2;
F2 = F2.^2;

for nrm = NRM
    
    tloc = tic;
    
    if isinf(nrm)
        F = Fi; fmax = fi;
    elseif nrm == 2
        F = F2; fmax = f2;
    else
        F = F1; fmax = f1;
    end;
    
    % Find function values within ftol of maximum
    I = find(F>ftol*fmax);
    
    d = size(X, 2);
    %n = sqrt(d) - 1;
    
    SY = c2sf(YS(:,I));
    %if isinf(nrm)
    %    SY = c2sf(X);
    %    I = [1:d];
    %elseif nrm == 2
    %    SY = [c2sf(YC) c2sf(X)];
    %else
    %    SY = c2sf(YC);
    %end;
    
    %options = optimset('GradObj', 'on', 'Display', 'iter', 'TolFun', 1e-8);
    options = optimset('GradObj', 'on', 'Display', 'off', 'TolFun', 1e-8);
    
    SMX = []; fmx = [];
    for i = 1:length(I)
        
        slb = [0; 0];
        sub = [pi; 2*pi];
        
        % Find local minimum accurately
        [ss, fs] = fminunc('normlagfg', SY(1:2,i), options, X, n, Ginv, nrm);
        fs = -fs;
        
        shift = floor(ss/(2*pi));
        ss = ss - shift*(2*pi);
        if ss(1) > pi
            ss(1) = 2*pi - ss(1);
            if ss(2) < pi
                ss(2) = ss(2) + pi;
            else
                ss(2) = ss(2) - pi;
            end;
        end;
        fschk = -normlagfg(ss, X, n, Ginv, nrm);
        
        if ~isempty(SMX)
            Z = SMX - ss*ones(1,size(SMX,2));
            Z = sum(Z.*Z);
        else
            Z = 1;
        end;
        
        if (all(Z > 1e-4) & (fs > ftol*fmax)) | fs > max(fmx)+eps
            SMX = [SMX ss];
            fmx = [fmx fs];
        end;
        
    end;
    
    [fmx, I] = sort(fmx, 'descend');
    %I = fliplr(I);
    %fmx = fliplr(fmx);
    SMX = SMX(:,I);
    
    if isinf(nrm)
        lagnrm.inf = fmx(1);
        lagnrm.inf_fmx = fmx;
        lagnrm.inf_pts = SMX;
    elseif nrm == 2
        % For 2-norm have maximized sum of squares, so take sqrt to get norm
        fmx = sqrt(fmx);
        lagnrm.two = fmx(1);
        lagnrm.two_fmx = fmx;
        lagnrm.two_pts = SMX;
    else
        lagnrm.one = fmx(1);
        lagnrm.one_fmx = fmx;
        lagnrm.one_pts = SMX;
    end;
    
    tloc = toc(tloc);
    
    if ipr
        if isinf(nrm)
            fprintf('==== %d norm of Lagrangians: max_{x in S^2} ||l(x)||_%d  - 1 = %.1e ====\n', nrm, nrm, fmx(1)-1);
        else
            fprintf('==== %d norm of Lagrangians: max_{x in S^2} ||l(x)||_%d = %.8e   ====\n', nrm, nrm, fmx(1));
        end;
        fprintf('     n = %d, d = %d with %d local maxima (ftol = %.2f:)', n ,d, length(fmx), ftol);
        fprintf(' Time = %.2f secs\n', tloc);
    end;
    
end;

tc = toc(t0);
if ipr
    fprintf('For n = %d, m = %d: total time = %.2f secs\n', n, d, tc);
end;

