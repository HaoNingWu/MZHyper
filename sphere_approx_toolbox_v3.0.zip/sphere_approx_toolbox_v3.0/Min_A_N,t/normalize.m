function [Y, Q, R] = normalize(X)
% [Y, Q, R] = normalize(X)
% Normalize at set of points in R^3, stored as columns of X,
% so they all lie on the unit sphere and have 
% first point is at the north pole X(:,1) = [0; 0; 1], and the
% second X(:,2) on the prime meridian, X(2,2) = 0, with X(1,2) > 0

% Normalize first to force all points to be on unit sphere
v = sqrt(sum(X.*X));
Y = X./v(ones(size(X,1),1),:);
%%
m = size(X,2);
if m > 1
   % Rotate first point to [0; 0; 1] and second to [x; 0; z]
   [Q, R] = qr(Y(:,1:2));
else
   % Rotate first point to [0; 0; 1]
   [Q, R] = qr(Y(:,1));
end;
if R(1,1) < 0
   Q = -Q(:,[2 3 1]);
else
   Q = Q(:,[2 3 1]);
end;
if Q(:,1)'*Y(:,2) < 0
   Q(:,1) = -Q(:,1);
end;

Y = Q'*Y;
