function [f1, f2, fi, F1, F2, Fi] = normlag(X, n, GI, Y, ipr)
% [f1, f2, fi, F1, F2, Fi] = normlag(X, n, GI, Y, ipr)
% Calculate the 1-norm (f1), 2-norm (f2) or infinity norm (fi)
% of the Lagrangians GI*g(x), where GI = G^{-1},
% The global maximum of f over the sphere gives the
% for inrm = 0 the C -> C interpolation operator norm (default)
% for inrm = 1 the maximum absolute value of all Lagrangians
% -- Input arguments --
% X = 3 by m array of interpolation points on the sphere
% GI = inverse of interpolation operator G, GI will be calculated if not passed
% Y = 3 by N array of sample points for estimating maximum over the sphere
% inrm = 1 for 1-norm = interpolation operator norm = Lebesgue constant
% inrm = 2 for Lagrangina sum of squares
% inrm = otherwise for infinity norm
% ipr > 0 for print out of results and time taken
% ipr > 1 also plots function at sample points over the spehre
% -- Output argument --
% f = value of \sum_{j=1}^d | GI g(x(s)) |
% F = 1 by N array of function values at sample points in Y (for plotting)

% Block algorithm to reduce storage requirements

t0 = cputime;

% Default to no printing
if nargin < 5
    ipr = 0;
end;

% Sample points for grid maximum over sphere
if nargin < 4
    Y = ptsfgs1(100);
end;

% Calculate GI = inv(G) if it is not provided
if nargin < 3
    G = gramxd(X);
    GI = inv(G);
end; 

% For interpolation d = (n+1)^2
m = size(X, 2);
if nargin < 2
    n = sqrt(m)-1;
end;
N = size(Y,2);
e = ones(3,1);

%theta = s(1); phi = s(2);
%ct = cos(theta); st = sin(theta);
%cp = cos(phi); sp = sin(phi);
%x = [st*cp; st*sp; ct];

% Initialize function value and gradient
F1 = zeros(1,N);
F2 = zeros(1,N);
Fi = zeros(1,N);

if strcmp(computer, 'PCWIN') | strcmp(computer, 'GLNX86')
    blksz = ceil(2096/m)+5;
else
    blksz = ceil(4096/m);
end;;
nblk = ceil(N/blksz);
for  blk = 1:nblk
    
    %flops(0);
    
    K = [(blk-1)*blksz+1: min(blk*blksz,N)];
    
    % Calculate m by N array of angles between given points X and points Y
    Z = X' * Y(:,K);
    
    % For points on sphere (i.e. ||X(:,i)||_2 == 1, ||x(:,j)||_2 == 1)
    % should have Z in [-1, 1]
    Zmin = min(min(Z));
    Zmax = max(max(Z));
    if Zmin < -1 | Zmax > 1
        % Make sure elements of Z are in [-1, 1]
        Z = max(Z, -1);
        Z = min(Z, 1);
    end;
    
    % Recurrence for Legendre polynomials
    P0 = ones(size(Z));
    P1 = Z;
    H = P0 + 3*Z;
    
    % Information to accumulate derivatives of g(x) w.r.t. x
    %Q0 = zeros(3,size(Z,2));
    %Q1 = X;
    %HD = 3*Q1;
    
    for k = 2:n
        
        km = (2*k-1)/k;
        kk = (k-1)/k;
        kp = 2*k+1;
        
        P = km*Z.*P1 - kk*P0;
        H = H + kp*P;
        
        %Q = km*(X.*P1(e,:) + Z(e,:).*Q1) - kk*Q0;
        %HD = HD + kp*Q;
        
        P0 = P1;
        P1 = P;
        
        %Q0 = Q1;
        %Q1 = Q;
        
    end;
    
    % Normalize by surface area of sphere |S^2|
    S2norm = 4*pi;
    H = H / S2norm;
    %HD = HD / S2norm;
    
    % Calculate inv(G)*H = GI*H and max or sum of abs(LH)
    H = GI*H;
    Fi(:,K) = max(abs(H));
    F2(:,K) = sqrt(sum(H.*H));
    F1(:,K) = sum(abs(H));
    
end;

fi = max(Fi);
f2 = max(F2);
f1 = max(F1);

tc = cputime - t0;
if ipr > 0
    fprintf('Calculating the degree %d (m = %d) Lagrangian functions at %d points\n', n, m, N);
    fprintf('Maximum of ||l(x)||_1 over the sphere = %.15f\n', f1);
    fprintf('Maximum of ||l(x)||_2 over the sphere = %.15f\n', f2);
    fprintf('Maximum of ||l(x)||_i over the sphere = %.15f\n', fi);
    fprintf('Calculation time = %.2f secs\n', tc);
end;
if ipr > 1
    str1 = sprintf('1-norm of Lagrangians');
    pltfunc(F1, Y, str1, 1, 0.5, 1);
    str2 = sprintf('2-norm of Lagrangians');
    pltfunc(F2, Y, str2, 3, 0.5, 1);
    stri = sprintf('Infinity-norm of Lagrangians');
    pltfunc(Fi, Y, stri, 5, 0.5, 1);
end;

