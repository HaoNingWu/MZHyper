function [sh, shp] = pltsph1(X, tstr, ifig)
% [sh, shp] = pltsph1(X, tstr, ifig, imesh)
% Plot 3 by d array of cartesian points X on the sphere in R^3
% tstr gives the title string for the plots
% ifig gives figure number in which plot is drawn
% imesh is 1 if underlying sphere is to be a mesh instead of a surface
% Only the first input argument X is required
% Output arguments sh and shp are handles to underlying sphere and points

if nargin < 3
    ifig = 1;
end;
m = size(X,2);
if nargin < 2
    tstr = sprintf('%d points', m);
end;

% Number of points for drawing point spheres
npts = 10; %80;
%npts = 100;

% view
v = [-45, 30];
%v = [39, 12];

% Position of figure window
%pos = [980 600 300 300];

% Small sphere for plotting points
% Marker size ms for points
% Scale for small spheres for points
[x, y, z] = sphere(npts);
%ms = 10;
ms = 2;
% Packing radius
pr = minang(X)/2;
cr = meshn(X);
fprintf('%d points, packing radius = %.4f', m, pr);
fprintf(', covering radius = %.4f, mesh ration = %.4f\n', cr, cr/pr);

sc0 = 1;
scale = 0.03;
xs = scale*x; ys = scale*y; zs = scale*z;
fprintf('Scale of points = %.4f\n', scale);

figure(ifig)
%set(ifig, 'Position', pos);
%set(ifig, 'PaperPositionMode', 'Auto')

% Detailed underlying sphere
[x0, y0, z0] = sphere(200);
sh = surf(x0, y0, z0);
shading('interp');

hold on
%col = ones(size(z));
for i = 1:m
   X1 = sc0*X(1,i) + xs;
   X2 = sc0*X(2,i) + ys;
   X3 = sc0*X(3,i) + zs;
   %C = sqrt(X1.^2 + X2.^2 + X3.^2);
   %shp(i) = surface(X1, X2, X3, C);
   shp(i) = surface(X1, X2, X3);
end;
hold off
shading('interp')

view(180, 0);
axis tight equal
axis vis3d
view(X(:,2))

%title(tstr);

axis off
set(sh, 'FaceColor', [0 0 1]);
set(shp, 'FaceColor', [1 0 0]);
% set(shp, 'FaceColor', [1 0.1 0.1]);
set(shp(1), 'FaceColor', [1 1 0.1]);
set(shp(2), 'FaceColor', [1 1 0.4]);
[amin, amax, imin, jmin] = minang(X);
set(shp(imin), 'FaceColor', [0.8 0.8 1]);
set(shp(jmin), 'FaceColor', [0.9 0.9 1]);
camlight('headlight', 'infinite')
set(sh, 'SpecularStrength', 0.1);
set(shp, 'SpecularStrength', 0.1);

