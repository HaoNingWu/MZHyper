% Spherical L-design with N points
% Either minimize the Sloan & Womersley function A_{L,N}
% or the sum of squares of the residual r = Y*e
% These are related by A_{L,N} = (|S^d| / N^2) r'*r
% From good starting points, minimizing sum of squares is more efficient
% Rob Womersely, School of Mathematics and Statistics, UNSW
%modifed by AN Congpei 
% function [XX,detG]=sdmin(p)
%--------------------------------------------------------------------------
%----------------
close all
extremal;%load data
% energypoint%
%    X0=me7;%you can change N=(L+?).^2 and check the Gram(L+?) as you wish
 X0=e8; 
% X = ptsspb(400, 8, 9, 1.8);
%  X0=X;
%%-mini energy
%-------------------------------------------
format compact
clc
% Specify degree L
 L =8
 ;
% Specify number of points N

% N = (L+4)^2;
N=81
% Specify objective to be minimized,i.e choose you want min
% Minimize sum of squares of residual r = Y*e
 objective = 'sfresid';
% Minimize spherical design objective of Sloan & Womersley
%   objective = 'sdobj';
%  objective = 'sfresid';

% Starting point set to load
pstr = 'me';
pdir = '../../Points/';

% Pseudo-random perturbation of initial spehrical points
% No perturbation of initial point set
pert = 0;%by your choose

% Based on the minimum angle ~ Pi/(L+1) for spherical design N ~ L^2/2
%pert = 0.5*pi/(L+1);
% Pseudo-random inital point set
%     pert = -1;
% % Restart from previous iterate
%    pert = -2;

tolx = 1e-14;
tolf = 1e-12;

% Define strings for loading initial point sets
Lstr = sprintf('%.3f', L/1e3); Lstr = Lstr(3:end);
Nstr = sprintf('%.5f', N/1e5); Nstr = Nstr(3:end);
%Lstr = sprintf('%.2f', L/1e2); Lstr = Lstr(3:end);
%Nstr = sprintf('%.4f', N/1e4); Nstr = Nstr(3:end);

if pert >= 0
%     Pstr = [upper(pstr) '/' pstr];%
%     ldstr = ['load ' pdir Pstr Lstr '.' Nstr];%
%     fprintf('Starting points: %s\n', ldstr);%
%     eval(ldstr);%
%     X0str = ['X0 = ' pstr Lstr '(:,1:3)'';'];%
%     eval(X0str)%
load('XX.mat')
    s0 = c2sn(X0);
end;

if pert > 0
    % Pseudo randm perturbations
    srnd = 2*rand(size(s0))-1
    % First N-1 elments are angles theta in [0, pi]
    % Elements N to 2*N-3 are angles phi in [0, 2*pi)
    s0 = s0 + pert*[srnd(1:N-1) 2*srnd(N:end)];
    X0 = s2cn(s0);
    s0 = c2sn(X0)
    fprintf('Perturbing intial points: pert = %3e\n', pert);
elseif pert == 0
    % Loaded initial point set
    X0 = s2cn(s0);
    fprintf('No perturbation of intial points\n');
elseif pert == -1
    % Pseudo-random points
    z = 2*rand(1,N-1) - 1;
    s0 = acos(z);
    s0 = [s0 (2*pi)*rand(1,N-2)];
    %s0 = ss;
    X0 = s2cn(s0);
    s0 = c2sn(X0);
    fprintf('Pseudo-random intial points\n');
elseif pert == -2
    % Restart from lst point from optimization
    % after mapping back to standard domain
    s0 = ss;
    X0 = s2cn(s0);
    s0 = c2sn(X0);
    fprintf('Restart intial points\n');
end;

fprintf('\n ---- Initial point set -----\n');
f0 = sdobj(s0, L, 1);
r0 = sfresid(s0, L, 1);
h0 = meshn(X0, 1);
a0 = minang(X0, 1);


opt = optimset('Display', 'Iter', 'TolX', tolx, 'TolFun', tolf);

% Select optimization method
if strcmp(objective, 'sfresid')
    % Minimize sum of squares of residual
    opt = optimset(opt, 'Jacobian', 'on');
    lb = []; ub = [];
    [ss, rssq, rr, flag] = lsqnonlin('sfresid', s0, lb, ub, opt, L);
    fprintf('LSQNONLIN: flag = %d\n', flag);
    [rs, A] = sfresid(ss, L, 3);
    XX = s2cn(ss);
elseif strcmp(objective, 'sdobj')
    % Minimize objective A_{L,N}
    % Quasi-Newton method has potenital problems from
    % periodicity of spherical parametrization of sphere
     opt = optimset(opt, 'GradObj', 'on', 'LargeScale', 'off');
%     opt = optimset(opt, 'InitialHessType', 'scaled-identity');
    [ss, fs, flag] = fminunc('sdobj', s0, opt, L);
    fprintf('FMINUNC: flag = %d\n', flag);
    [f, g] = sdobj(ss, L, 3);
    XX = s2cn(ss);
end;
XX;
%%%%%%--------------------------------------------------------------------
%main body end

L1=L+1;
L2=L+2;
L3=L+3;
L4=L+4;
L5=L+5;
%________________________________
G0=gramxddL(XX, L);
G00=G0+ones(size(G0));
detG00=det(G00);
detG0=det(G0);
[G,detG,eignvalue2,meaneign,tr,condG,eigG]=Gram(XX,L);
% detG,eignvalue2,meaneign,condG
%---------------------------------L+1
G=gramxddL(XX, L1);
G=G+ones(size(G));
a=4*pi;
G=G/a;
detG=det(G);
[G1,detG1,eignvalue21,meaneign1,tr1,condG1,eigG1]=Gram(XX,L1);
% detG1,eignvalue21,meaneign1,condG1,eigp1;
pltsphp(XX)

d=eig(G);
dsort=sort(d,'descend');
mind=min(abs(d));
prodd=prod(d)%------detG
logprod=log(prodd);
f0
maxmin=max(d)/min(d);
% Discrepancy=Gdiscrepancy(XX')
%-------------------------------------L+2

[G2,detG2,eignvalue22,meaneign2,tr2,condG2,eigG2]=Gram(XX,L2);
% detG2,eignvalue22,meaneign2,condG2,eigp2;

%__________________________L+3
[G3,detG3,eignvalue23,meaneign3,tr3,condG3,eigG3]=Gram(XX,L3);
%------------------------------------------------L+4

[G4,detG4,eignvalue24,meaneign4,tr4,condG4,eigG4]=Gram(XX,L4);
%------------------------------------------------L+5

[G5,detG5,eignvalue25,meaneign5,tr5,condG5,eigG5]=Gram(XX,L5);


% detG3,eignvalue23,meaneign3,condG3,eigp3;
%&-----------------------------comparision
detG;eignvalue2,meaneign;condG;eigG;
detG1;eignvalue21,meaneign1;condG1;eigG1;
detG2;eignvalue22,meaneign2;condG2;eigG2;
detG3;eignvalue23,meaneign3;condG3;eigG3;
detG4;eignvalue24,meaneign4;condG4;eigG4;
detG5;eignvalue25,meaneign5;condG5;eigG5;

disnorm=norm(XX-X0)
f0,f
 tr,tr1,tr2,tr3
 %-------------------------------------------------------
 %eignvalue comparsion
 figure(2) ,plot(eigG1,'o','Linewidth',0.4,'MarkerSize',1.8)
hold on ,plot(eigG2,'x')
hold on ,plot(eigG3,'d','Linewidth',3,'MarkerSize',1.7)
hold on ,plot(eigG4,'r+','Linewidth',5,'MarkerSize',1.6)
hold on ,plot(eigG5,'sk','Linewidth',3,'MarkerSize',1.5)
%L=?
title('Eignvalue for  Gram matrice of spherical  t=4 design N=(t+4).^2 ','fontSize',12)%%
xlabel('Number','fontSize',19)
ylabel('Eignvalue for gram matrix','fontSize',19)
h = legend('eignvalue of G_{t+1}','eignvalue of G_{t+2}','eignvalue of G_{t+3}','eignvalue of G_{t+4}','eignvalue of G_{t+5}',5);%

 %-------------------------------------------------------------------------
 %-
 fL = sdobj(XX, L+1, 3);
 Weyle%estimate of eignvalue.
%  eigG
Y=inmds(XX,L);
minY=min(svd(Y))
Y1=inmds(XX,L+1);
minY1=min(svd(Y1))

% [sd,minsd,YT]=YSVD(L,XX);
% minsd
%  [sd,minsd1,YT]=YSVD(L+1,XX);
%  sd ,
fprintf('\n ---- terminate point set -----\n');
ft = sdobj(XX, L, 1);
rt = sfresid(XX, L, 1);
ht = meshn(XX, 1);
at = minang(XX, 1);
% minsd
%  minsd1
%  TraceYT=sum(sd.*sd)
 %svd of spherical harmonics Y
 mang=minang(XX)
 %minang best is around 0.2721