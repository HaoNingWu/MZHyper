 

L=19;
% N=200
F=[];NN=[];MY=[];MY1=[];
H=[];Angle=[];
XS=[];RS=[];
MY0=[];
MY10=[];
 for N=200:441
%  N=441
% z = 2*rand(1,N-1) - 1;
%     s0 = acos(z);
%     s0 = [s0 (2*pi)*rand(1,N-2)];
%     %s0 = ss;
%     X0 = s2cn(s0);
%     s0 = c2sn(X0);
%     fprintf('Pseudo-random intial points\n');
% 
% N=(L+2)^2
X0= ptsspb(N, 8, 9, 1.8);
Y0=inmds(X0,L);
minY0=min(svd(Y0))
Y10=inmds(X0,L+1);
minY10=min(svd(Y10))
MY0(end+1,:)=minY0;
MY10(end+1,:)=minY10;
[f,N,XX,minY,minY1,ht,at,s] = Amin(X0,L);
%   KMatrix1(end+1,:) = KArray1 ;
%             KMatrix2(end+1,:) = KArray2 ;
F(end+1,:)=f;
NN(end+1,:)=N;
XS=[XS,XX];
MY(end+1,:)=minY;
MY1(end+1,:)=minY1;
H(end+1,:)=ht;
Angle(end+1,:)=at;RS(end+1,:)=s;
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x=10:144
   x=200:441;
%    x=200:200+1185;
figure(11),plot(x,F,'*'),grid on,xlabel('Number of Points');title('The behavior of final A_{N,19} ','fontSize',12),set(gca, 'YScale', 'log')
  figure(12),plot(x,MY,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal singular vaule of Y_{19}','fontSize',12),set(gca, 'YScale', 'log')
   figure(13),plot(x,MY1,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal singular vaule of Y_{19+1}','fontSize',12),set(gca, 'YScale', 'log')
    figure(14),plot(x,H,'*'),grid on,xlabel('Number of Points');title('The behavior of mesh norm ','fontSize',12),
     figure(15),plot(x,Angle,'*'),grid on,xlabel('Number of Points');title('The behavior of minimal angle ','fontSize',12),
 
 figure(16),plot(x,RS,'*'),grid on,xlabel('Number of Points');title('The behavior of 2-norm of residual  ','fontSize',12),set(gca, 'YScale', 'log')
%$%%%%%
 figure(120),plot(x,MY,'*'),hold on,plot(x,MY0,'r^'),h = legend('initial','final',2);grid on,xlabel('Number of Points');title('The behavior of initial and final minimal singular vaule of Y_{19}','fontSize',12),set(gca, 'YScale', 'log')
   figure(130),plot(x,MY1,'*',x,MY10,'r^'),h = legend('initial','final',2),grid on,xlabel('Number of Points');title('The behavior of initial and final minimal singular vaule of Y_{19+1}','fontSize',12),set(gca, 'YScale', 'log')
    