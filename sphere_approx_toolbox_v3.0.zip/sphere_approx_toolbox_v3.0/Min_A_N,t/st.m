%%%%
close all
CWpoint;
opt = optimset(opt, 'Jacobian', 'off');
% opt = optimset(lsqnonlin);
% X0=e8;
X = ptsspb(23*23, 8, 9, 1.8);
X0=X;
L=19
s0 = c2sn(X0);
lb = []; ub = [];
%  [ss, rssq, rr, flag] = lsqnonlin('station', s0, lb, ub, opt, L);
   [ss, rssq, rr, flag] = lsqnonlin('station', s0, lb, ub, opt, L);
%     [ss, rssq, rr, flag] = lsqnonlin('station', s0, lb, ub,opt,L)
[rs, A] = sfresid(ss, L, 3);
JJ=A'*rs;NN=norm(JJ);
[a,A] =station(ss,L);
% a
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NN=norm(JJ);
 XXX = s2cn(ss);
figure(99), pltsphp(XXX)

[sd,minsd,YT]=YSVD(L,XXX);
 TraceYT=sum(sd.*sd)
 MineigG=min(eig(YT*YT'))
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
[sd1,minsd1,YT1]=YSVD(L+1,XXX);%check if XXX is a fundamental system for P_{t+1}
%  sd ,
 TraceYT1=sum(sd1.*sd1)
 MineigG=min(eig(YT1*YT1'))
  logminsd=log(minsd)
logminsd1=log(minsd1)
 [f] = sdobj(XXX, L, 3)
 NN,a
 minang(XXX)%%%%%%%around 0.2721 is good