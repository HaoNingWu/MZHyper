function [a,A] =station(s0,n)

[r, A] = sfresid(s0, n, 3);

a=A'*r;

 a=(norm(a)).^2

% opt = optimset(opt, 'Jacobian', 'on');
%     lb = []; ub = [];
% [ss, rssq, rr, flag] = lsqnonlin('station', s0, lb, ub, opt, L);
%   XX = s2cn(ss);
 %[a]=station(XX,L)