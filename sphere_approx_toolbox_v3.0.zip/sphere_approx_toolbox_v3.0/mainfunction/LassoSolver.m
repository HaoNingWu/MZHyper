function [ alpha, history ] = LassoSolver( obj, YL, f, lambda, beta, varargin )
%L2L1SOLVER Summary of this function goes here
%   Detailed explanation goes here
% Solves the following problem directly:
%   RL is a diag matrix
%
%   minimize || YL*alpha - f ||_2^2 + \lambda || RL'*alpha ||_1
%	
%   RL is a dian
%  input:	obj: objective function, (function handle)
%           YL:  spherical function matrix of pointset, ((L+1)^2*N)
%           w:   integral weight( for std, it's pi/4 ), (N*1)
%           f:   real value, (N*1)
%           t:   degree of pointset, (1*1)
%           beta: regularization operator of model, ((L+1)^2*1)
%           lambda: regularization parameter of model, (1*1)
%           rho: penalty parameter of lagrangian multiplier
%           relaxation:  relaxation parameter in z-update ([1, 1.8])
%  output:  alpha: solution, ((L+1)^2*1)
%           history: contains the objective value, the primal and dual 
%                    residual norms, and the tolerances for the primal and 
%                    dual residual norms at each iteration.(struct)

% Global constants and defaults
QUIET    = 0;
MAX_ITER = 1000;

% Data preprocessing
% m = (L+1)^2
% n = N , number of point set
[m, n] = size(YL);

% save a matrix-vector multiply
% TL = YL*YL' + lambda*diag(beta)*(YL*YL')*diag(beta)';
YLf = YL*f;
% YLf_w = 4*pi*YLf/n;
% solver
L = sqrt(m)-1;

% alpha_1 = zeros(m, 1);
% if max(beta - ones(m, 1)) > 1e-10
%     error('Not the Corresponding Operator, Please use other Solver')
% end

%% solution 1, use one expression
alpha = max( zeros(m, 1), (2*pi/n) * (2*YLf - lambda*beta) ) ...
    + min( zeros(m, 1), (2*pi/n) * (2*YLf + lambda*beta) );

[history.obj_val, history.item_1, history.item_2] ...
    = obj(YL, f, lambda, beta, alpha);

end
% 
% 

% X = X_k(:, 1:3)';
% clear X_k;
% 
% % get spherical harmonic matrix (Q_*)_{i,l^2+k}:=Y_{l,k}(x_i^*)
% if isfield(model_parameter, 'Y_L')
%     Y_L = model_parameter.Y_L;
% else
%     Y_L = getQ( X', L )';
% end
% YLf = Y_L*f;

