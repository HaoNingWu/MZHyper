function [ res ] = Solver( solver, X_k, f, model_parameter  )
%SOLVER Summary of this function goes here
%   Detailed explanation goes here
% input:
%       func: function (function handle)
%       solver: solver to solve proble include 'L2L2','L2L1';
%       X_k : point set on sphere and weight, 4*N
%       f : function value;
%       model_parameter: parameter of model, include
%           t ; degree of point set
%           L: degree of polynomial
%           lambda : regularization parameter (column vector, n_lambda*1)
%           delta : the range of perturbation (column vector, n_delta*1)
%           type_reg : regular terms ,

disp('start function: Solver');
%% parameter Preprocess
% degree of point set
if isfield(model_parameter, 't')
    t = model_parameter.t;
else
    t = 2;
end
% degree of polynomial
if isfield(model_parameter, 'L')
    
    L = model_parameter.L;
else
    L = 2;
end
% type of regularization operator
if isfield(model_parameter, 'reg_type')
    reg_type = model_parameter.reg_type;
else
    reg_type = 2;
end
% type of regularization parameter,
% such as filter function type, s in laplace operator
if isfield(model_parameter, 'reg_parameter')
    reg_parameter = model_parameter.reg_parameter;
else
    reg_parameter = struct();
end
% perturbation ratio on function
if isfield(model_parameter, 'func_delta')
    func_delta = model_parameter.func_delta;
else
    func_delta = 1;
end
% regularization parameter
if isfield(model_parameter, 'lambda')
    lambda = model_parameter.lambda;
else
    lambda = 0;
end
% number of point set
N = size( X_k, 2 );
% get point set for eval the L2/uniform error
% [ Xt ] = get_Xt( );

%% Get matrix Y_{ell, k} and reg matrix beta
% point set for model
X = X_k(:, 1:3)';
clear X_k;

% get spherical harmonic matrix (Q_*)_{i,l^2+k}:=Y_{l,k}(x_i^*)
if isfield(model_parameter, 'Y_L')
    Y_L = model_parameter.Y_L;
else
    Y_L = getQ( X', L )';
end
% Y_L = getQ( X', L )';

% regularization matrix B
beta = reg_op( reg_type, L, reg_parameter );


%% start solver
disp('Start Solve Model');
obj = [];
relaxation = 1;

tic;
switch solver
    case 'L2L2'
        rho = 1;
        obj = @obj_L2L2;
        [ alpha, history ] = ...
            L2L2Solver( obj, Y_L, f, lambda, beta, t, L);
    case 'L2L1'
        % rho = (10^-1)*min(lambda(itr_lambda),1);
        obj = 1; %@obj_L2L1;
        rho = model_parameter.rho;
        [ alpha, history ] = ...
            L2L1Solver( obj, Y_L, f, lambda, beta, rho, t, L);
    case 'Lasso'
        rho = 1;
        obj = @obj_lasso;
        [ alpha, history ] = ...
            LassoSolver( obj, Y_L, f, lambda, beta, rho, relaxation);
end
% time_solver = toc;
% disp(num2str(time_solver));
% disp('End Solve Model');
% disp('');

res.delta = func_delta;
res.lambda = lambda;
res.alpha = alpha;
res.history = history;
res.f = f;

end

function [obj_val, item_1, item_2] = obj_L2L1(YL, f, lambda, beta, alpha, varargin)
%OBJ_LASSO Summary of this function goes here
%   Detailed explanation goes here

% value of each item
item_1 = sum((YL'*alpha - f).^2);
item_2 = norm(YL'*diag(beta)*alpha, 1);

% objective function value
obj_val = item_1 + lambda*item_2;

end

function [obj_val, item_1, item_2] = obj_lasso(YL, f, lambda, beta, alpha, varargin)
%OBJ_LASSO Summary of this function goes here
%   Detailed explanation goes here

% value of each item
item_1 = norm( YL'*alpha - f, 2).^2;
item_2 = norm( alpha, 1);

% objective function value
obj_val = item_1 + lambda*item_2;

end

function [obj_val, item_1, item_2] = obj_L2L2(YL, f, lambda, beta, alpha, varargin)
%OBJ_LASSO Summary of this function goes here
%   Detailed explanation goes here

% value of each item
item_1 = sum((YL'*alpha - f).^2);
item_2 = norm( (diag(beta)*YL)'*alpha, 2).^2;

% objective function value
obj_val = item_1 + lambda*item_2;

end

