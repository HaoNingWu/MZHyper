function [sca_data,S1,S2] = sca_data_cap(dim,M,N,r)
point_x1 = eq_point_set_cap(dim,M,r);
S1 = size(point_x1,2);
point_x2 = eq_point_set(dim,N,r);
S2 = size(point_x2,2);
sca_data=[point_x1,point_x2];