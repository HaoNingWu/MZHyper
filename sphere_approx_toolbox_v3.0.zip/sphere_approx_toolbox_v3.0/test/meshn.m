function [h, ht, CC, CE, imax] = meshn(X, ipr, ifig);
% [h, ht, CC, CE] = meshn(X, ipr, ifig)
% X is a 3 by m sets of points on the unit sphere S^2
% X�ǵ�λ������һ��3*m�ĵ㼯
% Values are printed if ipr > 0 (defaults to ipr = 0)
% ipr > 0 ��������н��
% h = maximum distance from closest point in X using the
% geodesic distance dist(x,y) = acos(x'*y)
% h ��X������ĵ㼯�ľ�������ֵ��ʹ�ò�ؾ���
% ht is the geodesic point furthest from vertices of each Delauney triangle
% ht��ÿ��Delatuney���ǵĽڵ��в�ؾ�����Զ��
% CC is array of circumcentres of each triangle in Delaunay trinagulation
% CC��ÿ��Delaunay�����е����Բ����
% CE is array of centroids of each triangle in Delaunay trinagulation
% CE��ÿ��Delaunay�����е��е㣨���߽��㣩

if nargin < 3
    ifig = 1;
end;
if nargin < 2
    ipr = 0;
end;

t0 = cputime;

% Scale facotr: 2 radian = sc degrees
sc = 180/pi;

m = size(X,2);

if m < 4
    ht = []; CC = []; CE = [];
    fprintf('MESHN: WARNING: cannot find convex hull of < 4 points\n');
    if m == 1
        h = pi;
    elseif m == 2
        v = X(:,1)+X(:,2);
        v = -v/norm(v);
        hh = acos(v'*X);
        h = max(pi/2,max(hh));
    else % m == 3
        x1 = X(:,1); x2 = X(:,2); x3 = X(:,3);
        [at, ai, aj, ak, R, r, xcc, xic] = areast(x1, x2, x3);
        v0 = -xcc;
        z0 = v0'*X;
        v1 = x1 + x2; v1 = -v1/norm(v1);
        z1 = v1'*X;
        v2 = x1 + x3; v2 = -v2/norm(v2);
        z2 = v2'*X;
        v3 = x2 + x3; v3 = -v3/norm(v3);
        z3 = v3'*X;
        h = min([max(z0) max(z1) max(z2) max(z3)]);
        h = acos(h);
        h = max(pi/2, h);
    end;
    return;
end;
vd1 = X(:,2) - X(:,1);
vd2 = X(:,3) - X(:,1);
vn = cross(vd1, vd2);
vn = vn/norm(vn);
z = vn'*X;
znrm = norm(z, inf);
ztol = 10*eps;
if znrm < ztol
    fprintf('MESHN WARNING: points coplanar, znrm = %.2e\n', znrm);
end;
if m < 21
    z = inprod(X);
    zmin = min(z);
    if zmin >= 0
        fprintf('MESHN WARNING: All points in a hemisphere, inprod > %.4e\n', zmin);
    end;
else
    zmin = -1;
end;

if znrm < ztol || zmin >= 0
%     ht = []; CC = []; CE = [];
    zmin = 1;
    for i = 1:m-1
        for j = i+1:m
            v = X(:,i)+X(:,j); v = -v/norm(v);
            z = v'*X ;
            zmin = min(zmin, max(z));
        end;
    end;
    h = max(pi/2, acos(zmin));
    %return;
end;

K = convhulln(X');
nK = size(K,1);

ht = zeros(1,nK);
CC = zeros(3,nK);
CE = zeros(3,nK);
for kk = 1:nK

    i = K(kk,1); j = K(kk,2); k = K(kk,3);
    xi = X(:,i); xj = X(:,j); xk = X(:,k);
    sgn = sign(det(X(:, [i j k])));
    xijk = cross(xi-xj, xi-xk);
    xnrm = sqrt(xijk'*xijk);
    ht(kk) = abs(xi'*cross(xj,xk))/xnrm;
    CC(:,kk) = sgn*xijk/xnrm;
    zk = xi + xj + xk;
    zk = zk / norm(zk,2);
    CE(:,kk) = zk;

end;

htg = acos(ht);
[h, imax] = max(htg);
actv = find(htg>0.99*h);
nactv = length(actv);
tc = cputime - t0;

if ipr > 0
    fprintf('Triangulation of %d points has %d traingles\n', m, nK);
    fprintf('Mesh norm (covering radius) = %.8f radians (%.8f degrees)\n', h, sc*h);
    fprintf('Number of Delaunay triangles achieving the covering radius = %d\n', nactv);
    fprintf('Calculation time = %.2f secs\n',  tc);
    if ipr > 1
        % pltcaps(X, h, 'Covering', ifig);
        str = sprintf('Covering with %d spherical caps of radius %.6f', m, h);
        %view(45,0);
        view(CC(:,imax));
        title(str);
        if ipr > 2 && ipr < 5
            hold on
            plot3(CC(1,:), CC(2,:), CC(3,:), 'g.', 'MarkerSize', 18);
            hold off
        end;
        if ipr > 3
            ncp = 200;
            lw = 1;
            hold on
            for kk = 1:nK
                i = K(kk,1); j = K(kk,2); k = K(kk,3);
                xi = X(:,i); xj = X(:,j); xk = X(:,k);
                P = gcarc(xi, xj, ncp);
                plot3(P(1,:), P(2,:), P(3,:), 'k-', 'LineWidth', lw);
                P = gcarc(xi, xk, ncp);
                plot3(P(1,:), P(2,:), P(3,:), 'k-', 'LineWidth', lw);
                P = gcarc(xj, xk, ncp);
                plot3(P(1,:), P(2,:), P(3,:), 'k-', 'LineWidth', lw);
            end;
            hold off
        end;
        if ipr > 4
            sc = h/6;
            [xs, ys, zs] = sphere(40);
            xs = sc*xs; ys = sc*ys; zs = sc*zs;
            hold on
            for j = 1:size(X,2);
                xj = X(:,j);
                sh = surf(xj(1)+xs, xj(2)+ys, xj(3)+zs, 'FaceColor', [1 0 0], 'EdgeColor', 'none');
            end;
            hold off
        end;
        if ipr > 6
            figure(ifig+1);
            plot([1:nK], htg, 'b.', [1 nK], h*[1 1], 'm-');
            str = sprintf('Radii of circumcircles of Delaunay triangles (%d active out of %d)', ...
                nactv, nK);
            title(str);
            set(gca, 'Xlim', [0 nK+1]);
            set(gca, 'Ylim', [0.9*min(htg), 1.1*h]);
            grid on
        end;
    end;
end;

end


