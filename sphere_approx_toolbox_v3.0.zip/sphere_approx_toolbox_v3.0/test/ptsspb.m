function X = ptsspb(N, nn, ipr, C)
% X = ptsspb(N, nn, ipr, C)
% Generate N equal area points X on the unit sphere S^2 in R^3
% Ref: R. Bauer, "Distribution of Points on a Sphere with Application
% to Star Catalogs ", Journal of Guidance, Control, and Dynamics,
% January-February 2000, vol.23 no.1 (130-137). 
% Original version does not put points at north or south poles (nn = 1)
% Normalized by a rotation of first point to north pole and second to
% the prime meridian, unless nn = 1 (default nn = 0)
% If ipr > 0 print a one line summary
% Parameter C affects phi angles: Bauer sqrt(pi), RSZ 1.8 (default)

if nargin < 4
    C = 1.8;
end;

if nargin < 3
    ipr = 0;
end;

if nargin < 2
    nn = 0;
end;

K = [1:N];

% Original version starts close to south pole
%h = -1 + (2*K-1)/N;

% Start close to north pole  
h = 1 - (2*K-1)/N;

% Polar angle
theta = acos(h);

% Azimuthal angle
% Bauer uses sqrt(pi)
%C = sqrt(pi);
% Emperical value of RSZ in ptsgsp
%C = 1.8;
phi = C*sqrt(N)*theta;

S = [theta; phi; ones(1,N)];
X = s2cf(S);

if nn ~= 1
    X = normalize(X);
    nstr = ' normalized';
else
    nstr = '';
end;

if ipr > 0
    fprintf('Generating %d%s Bauer spiral points (SB) for C = %.3f\n', N, nstr, C);
end;
% [Y, Q, R] = normalize(X)
% X=[Y,Q,R]
pltsphp(X)