function [ pt, abs_error, L2_error, uniform_error ] = error_eval( alpha, func )
%ERROR_EVAL Summary of this function goes here
%   Detailed explanation goes here

% ������
L = sqrt(length(alpha))-1;
Xt = get_Xt( );
% ft = func(Xt, 0);
ft = func(Xt',2);
Yt_eqp = get_Yt( L, Xt );
pt_eqp = Yt_eqp * alpha;
abs_error = pt_eqp-ft;
uniform_error = norm( pt_eqp-ft, inf );
L2_error = sqrt((norm(pt_eqp-ft,2).^2)/length(ft) );

% 
% X_std = load('std160_25921.mat');
% X_std = X_std.std;
% Yt_std = get_Yt( L, X_std' );
% ft = func(X_std, 0);
% pt_std = Yt_std * alpha;
% L2_error = sqrt((norm(pt_std-ft,2).^2)/length(ft) );

pt = pt_eqp;
end

