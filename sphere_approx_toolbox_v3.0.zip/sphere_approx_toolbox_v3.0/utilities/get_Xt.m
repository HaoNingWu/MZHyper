function [ Xt ] = get_Xt( )
%GET_XT_YT Summary of this function goes here
%   Detailed explanation goes here
if exist('Xt.mat', 'file')
    load Xt.mat
else
    Xt = sca_data_cap(2, 1, 50000, 0); % ����ʵֵ(�ɴ洢-->% load Xt )
    save Xt.mat Xt
end

end

% ȫ�ֱ��� Yt
% global Yt
% if exist('Yt.mat', 'file')
%     mat_obj_Yt = matfile('Yt.mat');
%     Yt = mat_obj_Yt.Yt(:, (max_L+1)^2);
% else
%     Yt = getQ(Xt', max_L); % ����ʵֵ(�ɴ洢-->% load Xt )
%     % save Xt.mat Xt
% end
% if isempty(Yt)
    %     if exist('/Xt.mat', 'file')
    %         load Xt.mat
    %     else
    %         Xt = sca_data_cap(2, 1, 50000, 0); % ����ʵֵ(�ɴ洢-->% load Xt )
    %         save Xt.mat Xt
    %     end
    %     L = fix(t/2);
%     Yt = getQ_T(Xt', max_L);
%     save('Yt_tran.mat', 'Yt', '-mat', '-v7.3')
% end
