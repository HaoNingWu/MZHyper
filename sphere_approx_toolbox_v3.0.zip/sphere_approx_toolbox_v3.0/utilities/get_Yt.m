function [ Yt ] = get_Yt( max_L, Xt )
%GET_XT_YT Summary of this function goes here
%   Detailed explanation goes here

Yt = getQ(Xt', max_L); 

end

