function [ name ] = get_reg_op_name( type )
%GET_REG_OP_NAME Summary of this function goes here
%   Detailed explanation goes here

% regularization operator
%   type 1 : 0 operator
%   type 2 : filter operator
%   type 3 : laplace-beltrami regularization
%   type 4 : Identity Operator

switch type
    case 1
        % O ����
        name = '0 operator';
    case 2
        % filter ����
        name = 'Filtered operator';
    case 3
        % Laplace-Beltrami����
        name = 'Laplace-Beltrami operator';
    case 4
        % Identity Operator
        name = 'Identity operator';
end


end

