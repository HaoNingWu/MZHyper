function [ X ] = loadStd( t, N )
%LOADSTD Summary of this function goes here
%   Detailed explanation goes here

% set path and file name of point set
path_pt = '/Users/haoningwu/Documents/MATLAB/hyperinterpolation/sphere_approx_toolbox_v3.0/sphere_approx_toolbox_v3.0/data/std';
filename_pt = ['/std', num2str(t, '%.3i'), '_', num2str(N, '%.5i'), '.mat'];

% load the point
pt = load([path_pt, filename_pt]);

% save to var X
X = pt.std(:, :);


end

