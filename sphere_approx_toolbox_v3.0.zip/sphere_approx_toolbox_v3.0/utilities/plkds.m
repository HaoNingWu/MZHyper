function [PL, DPLdt] = plkds(L, z)
%   [PL, DPLdt] = plkds(L, z)
%   Return a matrix PL containing the associated Legendre functions
%   P_L^0:P_L^L of degree L at the points z in [-1, 1]
%   This uses a version of the SPc of the Shmidt semi-normalized
%   associated Legendre functions from legendre1
%   Optionally return a matrix DPLdt containing the
%   derivative with respect to theta where z == cos(theta).
%
% -- Input arguments --
% L      : Degree, Integer >= 0
% z      : Row vector of points in [-1, 1] where functions are to be evaluated
% -- Output arguments --
% PL     : Matrix of size (L+1)*prod(size(z)) giving the function values at z
% DPLdt  : Matrix of size (L+1)*prod(size(z)) giving derivatives at z
%        : If called with only one output argument the derivative will not be calculated
%
%   See http://mathworld.wolfram.com/LegendrePolynomial.html
%   References:
%   A&S: Abramowitz & Stegun, "Handbook of Mathematical Functions".
%   PL: Paul Leopardi, "Computing derivatives of associated Legendre functions using Matlab".
%   S: Szego, "Orthogonal Polynomials".

%   Paul Leopardi and Rob Womersley
%   School of Mathematics and Statistics, UNSW
%   Based on SPHARM2:
%   Denise L. Chen  9-1-93
%   Copyright 1984-2000 The MathWorks, Inc.
%   $Revision: 5.10 $  $Date: 2000/06/01 03:46:27 $

if nargin == 0
  help plkds
  return;
end

CalcDt = nargout > 1;

% Ensure z is a row vector
% This will not work if z is an neither a row nor column vector
if size(z,2) == 1
    z = z';
end

k = 1:L;
lz = prod(size(z));

% Use recurrence from legendre with NO scaling to get SPc(n,m;x)
% where P(n,m;x) = sqrt((n+m)!/(n-m)!) * SPc(n,m;x)
PL = legendre1(L, z, 'spharm');

if CalcDt
    DPLdt = zeros(L+1,lz);
    if L > 0
        pole = abs(z) == 1;
        np = ~pole;
        if ~isempty(z(pole))
            % The following special cases for the derivatives at -1 and at 1
            % are defined in terms of limits. 
            % The formula for order 1 is PL Theorem 4.
            % It can be derived from S 4.21.7, p63, S 4.1.1, p58 and S 4.1.3, p59.
            % For all other orders, the derivative is 0, as per PL Theorems 3 and 5.
            DPLdt(2,pole) = -sqrt(L*(L+1))/2*PL(1,pole);
        end
        znp = z(np);
        if ~isempty(znp)
            oz = ones(size(znp));
            ok = ones(size(k))';
            snp = sqrt(1-znp.*znp);

            % The following general formula for the derivative is PL Theorem 1.
            % It can be derived from A&S 8.5.2, p334, assuming -1 < z < 1,
            % and P(n,m;x) = sqrt((n+m)!/(n-m)!) * SPc(n,m;x)
            clk = -sqrt(L+k).*sqrt(L-k+1);
            DPLdt(1+k,np) = (clk'*oz).*PL(k,np) - (k'*oz).*PL(1+k,np).*(ok*(znp./snp));

            % The following special case is PL Theorem 2.
            DPLdt(1,np) = sqrt(L)*sqrt(L+1)*PL(2,np);
        end
    end
end
