function [YL, DYLdt, DYLdp] = spharmrds(L, z, phi)
%[YL] = spharmrds(L, z, phi)
% [YL, DYLdt, DYLdp] = spharmrds(L, z, phi)
%   Return a matrix YL containing the real spherical harmonics
%   Y_{L,-L}:Y_{L,L} of degree L at the points (z, phi),
%   with (z,phi) representing points on the sphere S^2 in cylindrical
%   coordinates.
%   Optionally return matrices DYLdt and DYLdp containing
%   partial derivatives with respect to theta and phi
%   where z = cos(theta).
%
% -- Input arguments --
% L      : Degree, Integer >= 0
% z      : Row vector of altitudes of points where functions are to be evaluated
% phi    : Row vector of longitudes of points where functions are to be evaluated
% -- Output arguments --
% YL     : Matrix of size (2*L+1)*prod(size(z)) giving the function values at z
% DYLdt  : Matrix of size (2*L+1)*prod(size(z)) giving theta derivatives at z
% DYLdp  : Matrix of size (2*L+1)*prod(size(z)) giving phi derivatives at z
%        : If called with only one output argument the derivatives will not be calculated
%
%   Layout of the matrix YL is:
%   YL(1,:)   = Y_{L,-L}(z,phi) = scaled P_L^L(z)*sin(L*phi)
%   ...
%   YL(L,:)   = Y_{L,-1}(z,phi) = scaled P_L^1(z)*sin(phi)
%   YL(L+1,:) = Y_{L,0} (z,phi) = scaled P_L(z)
%   YL(L+2,:) = Y_{L,1} (z,phi) = scaled P_L^1(z)*cos(phi)
%   ...
%   YL(N,:)   = Y_{L,L} (z,phi) = scaled P_L^1(z)*cos(L*phi)
%
%   The matrices DYLdt and DYLdp have appropriate partial
%   derivatives in the corresponding positions.
%
%   See http://mathworld.wolfram.com/SphericalHarmonic.html
%   for definition.
%   See also http://mathworld.wolfram.com/LegendrePolynomial.html
%   References: 
%   A,A&R: Andrews, Askey & Roy, "Special Functions",
%   Cambridge, 1999, pp302-303, 456-457.
%   A&S: Abramowitz & Stegun, "Handbook of Mathematical Functions",
%   pp333-334,778


if nargin == 0
  help spharmrd
  return;
end

CalcDt = nargout > 1;
CalcDp = nargout > 2;

% Ensure input consists of row vectors
if size(z,2) == 1
    z = z';
end
if size(phi,2) == 1
    phi = phi';
end

% Get associated Legendre functions and derivatives.
if CalcDt
    [PL,DPLdt] = plkds(L,z);
else
    PL = plkds(L,z);
end

k = 1:L;
N = 2*L+1;
lz = prod(size(z));

YL = zeros(N,lz);
scaling = sqrt(N/(4*pi));
YL(1+L,:)        = scaling * PL(1,:);
if CalcDt
    DYLdt = zeros(N,lz);
    DYLdt(1+L,:) = scaling * DPLdt(1,:);
end
if CalcDp
    DYLdp = zeros(N,lz);
end

scaling = sqrt(N/(2*pi));
if L > 0
    
    % Only need to scale by a constant as unscaled associated Legendre
    % functions SPc are used
    scaledPL  = scaling * PL(1+k,:);
    
    kkp = k'*phi;

    % sin comes first, in reverse order
    sk = L:-1:1;

    % cos comes after P_L, in forward order
    ck = L+2:N;

    % Evaluate sin and cos 
    skkp = sin(kkp);
    ckkp = cos(kkp);
    
    YL(sk,:)        = scaledPL  .* skkp;
    YL(ck,:)        = scaledPL  .* ckkp;
    
    % If required, use Leibniz rule to calculate derivatives
    if CalcDt
        scaledDPLdt = scaling * DPLdt(1+k,:);
        DYLdt(sk,:) = scaledDPLdt .* skkp;
        DYLdt(ck,:) = scaledDPLdt .* ckkp;
    end
    if CalcDp
        DK = spdiags(k', 0, L, L); 
        DYLdp(sk,:) = scaledPL  .* ( DK * ckkp);
        DYLdp(ck,:) = scaledPL  .* ((-DK) * skkp);
    end
end
